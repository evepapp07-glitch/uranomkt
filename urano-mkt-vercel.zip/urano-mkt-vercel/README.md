# Urano mkt — Sitio Web

## Archivos
- `index.html` — Página principal
- `test.html` — Página del test (referencia, el test vive en index.html)
- `vercel.json` — Configuración de rutas para Vercel

## Cómo publicar en Vercel

### Opción 1 — Drag & Drop (más fácil)
1. Ir a [vercel.com](https://vercel.com) e iniciar sesión
2. Click en "Add New Project"
3. Arrastrar esta carpeta completa
4. Click en Deploy ✓

### Opción 2 — GitHub (recomendado para actualizar fácil)
1. Subir esta carpeta a un repositorio GitHub
2. En Vercel: "Add New Project" → importar desde GitHub
3. Deploy automático en cada push ✓

## Assets externos
El logo SVG (URANO_LOGO_svg.svg) se carga desde la misma carpeta.
Si no está, el nav mostrará el logo en texto de respaldo.
